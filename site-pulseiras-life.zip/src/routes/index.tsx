import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { ProductCard } from "@/components/product-card";
import { products } from "@/lib/products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pulseiras Life — Life Vivara" },
      { name: "description", content: "Pulseiras Life Vivara em prata 925 com pedras incolores." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <SiteLayout>
      <section className="max-w-6xl mx-auto px-4 pt-10 pb-6 text-center">
        <h1 className="font-serif text-5xl sm:text-6xl text-brand tracking-wide">PULSEIRAS LIFE</h1>
        <p className="text-primary mt-3 text-sm">{products.length} produtos</p>
      </section>
      <section className="max-w-6xl mx-auto px-4 pb-12 grid gap-4 grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </section>
    </SiteLayout>
  );
}
