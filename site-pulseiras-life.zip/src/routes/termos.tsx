import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";

export const Route = createFileRoute("/termos")({
  head: () => ({ meta: [{ title: "Termos — Life Vivara" }] }),
  component: TermosPage,
});

function TermosPage() {
  return (
    <SiteLayout>
      <section className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="font-serif text-4xl text-brand text-center mb-8">Termos e Condições</h1>
        <div className="prose prose-sm max-w-none space-y-6 text-foreground">
          <div>
            <h2 className="font-serif text-xl text-brand mb-2">1. Uso do site</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Ao navegar pelo Life Vivara, você concorda com estes termos. O conteúdo aqui exibido é
              meramente informativo e demonstrativo.
            </p>
          </div>
          <div>
            <h2 className="font-serif text-xl text-brand mb-2">2. Produtos e preços</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Os preços estão expressos em reais (R$) e podem ser alterados sem aviso prévio.
              Promoções têm validade limitada ao estoque disponível.
            </p>
          </div>
          <div>
            <h2 className="font-serif text-xl text-brand mb-2">3. Entrega</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Frete grátis em compras a partir de R$ 699,00. Prazo de entrega conforme localidade.
            </p>
          </div>
          <div>
            <h2 className="font-serif text-xl text-brand mb-2">4. Trocas e devoluções</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Você tem até 7 dias corridos após o recebimento para solicitar troca ou devolução,
              conforme o Código de Defesa do Consumidor.
            </p>
          </div>
          <div>
            <h2 className="font-serif text-xl text-brand mb-2">5. Privacidade</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Seus dados são utilizados apenas para processamento de pedidos e comunicação direta,
              respeitando a LGPD.
            </p>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
