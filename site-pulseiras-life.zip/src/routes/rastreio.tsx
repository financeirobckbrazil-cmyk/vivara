import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { toast } from "sonner";
import { BellRing, CheckCircle2, Loader2, MessageCircle, Package, ShieldCheck } from "lucide-react";
import { PixModal } from "@/components/PixModal";
import { checkPixStatus, createPix } from "@/lib/pix.functions";

export const Route = createFileRoute("/rastreio")({
  head: () => ({
    meta: [
      { title: "Rastreio no WhatsApp — Acompanhe seu pedido" },
      { name: "description", content: "Ative o acompanhamento do seu pedido no WhatsApp por apenas R$ 5,90 e receba atualizações automáticas do rastreio." },
      { property: "og:title", content: "Rastreio no WhatsApp — Acompanhe seu pedido" },
      { property: "og:description", content: "Atualizações automáticas do seu rastreio direto no WhatsApp por apenas R$ 5,90." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RastreioPage,
});

const AMOUNT_CENTS = 590;

function RastreioPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [externalId, setExternalId] = useState<string | null>(null);
  const [activated, setActivated] = useState(false);

  const handleActivate = async () => {
    setLoading(true);
    setModalOpen(true);
    try {
      const res = await createPix({ data: { amountCents: AMOUNT_CENTS } });
      if (!res.ok) {
        toast.error(res.error);
        setModalOpen(false);
        return;
      }
      setQrCode(res.qrCode);
      setExternalId(res.externalId);
    } catch {
      toast.error("Falha ao gerar o Pix. Tente novamente.");
      setModalOpen(false);
    } finally {
      setLoading(false);
    }
  };

  const handleCheck = useCallback(async (id: string) => {
    const res = await checkPixStatus({ data: { externalId: id } });
    if (res.status === "paid") setActivated(true);
    return res;
  }, []);

  if (activated) {
    return (
      <div className="mx-auto flex min-h-svh w-full max-w-[430px] flex-col items-center justify-center bg-white px-6 text-center">
        <CheckCircle2 className="h-20 w-20 text-green-500" />
        <h1 className="mt-4 text-xl font-bold text-gray-900">Acompanhamento ativado! 🎉</h1>
        <p className="mt-2 text-sm leading-relaxed text-gray-600">
          Você vai receber as atualizações do seu rastreio direto no WhatsApp a cada movimentação do pedido.
        </p>
        <p className="mt-6 flex items-center gap-1.5 text-xs text-gray-400">
          <ShieldCheck className="h-4 w-4" /> Pagamento 100% seguro
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto flex min-h-svh w-full max-w-[430px] flex-col bg-white">
      <div className="flex flex-col items-center px-6 pt-14 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-50">
          <Package className="h-10 w-10 text-green-600" />
        </div>
        <h1 className="mt-5 text-[22px] font-bold leading-snug text-gray-900">
          📦 Quer acompanhar seu pedido direto no WhatsApp?
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-gray-600">
          Por apenas <span className="font-bold text-green-600">R$ 5,90</span>, você recebe atualizações automáticas
          do seu rastreio direto no seu WhatsApp — sem precisar ficar copiando código em site nenhum.
        </p>
      </div>

      <div className="mx-6 mt-6 space-y-3 rounded-2xl bg-gray-50 p-5">
        {[
          "Notificação a cada movimentação",
          "Zero complicação",
          "Você sempre sabe onde seu pedido está",
        ].map((item) => (
          <div key={item} className="flex items-start gap-2.5">
            <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-500" />
            <span className="text-sm font-medium text-gray-800">{item}</span>
          </div>
        ))}
      </div>

      <div className="mx-6 mt-5 flex items-center gap-3 rounded-2xl border border-green-100 bg-green-50/60 p-4">
        <MessageCircle className="h-8 w-8 shrink-0 text-green-500" />
        <p className="text-xs leading-relaxed text-gray-600">
          Assim que o pagamento for confirmado, o acompanhamento é ativado automaticamente no seu número.
        </p>
      </div>

      <div className="mt-auto px-6 pb-8 pt-8">
        <div className="mb-3 flex items-center justify-between rounded-xl bg-gray-50 px-4 py-3">
          <span className="text-sm text-gray-500">Valor único</span>
          <span className="text-lg font-bold text-gray-900">R$ 5,90</span>
        </div>
        <button
          type="button"
          onClick={handleActivate}
          disabled={loading}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-green-500 py-4 text-base font-bold text-white shadow-lg shadow-green-500/30 transition active:scale-[0.98] disabled:opacity-60"
        >
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <BellRing className="h-5 w-5" />}
          {loading ? "Gerando Pix..." : "Ativar acompanhamento agora"}
        </button>
        <p className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-gray-400">
          <ShieldCheck className="h-3.5 w-3.5" /> Pagamento 100% seguro via Pix
        </p>
      </div>

      <PixModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        qrCode={qrCode}
        externalId={externalId}
        amountLabel="R$ 5,90"
        loading={loading}
        onCheck={handleCheck}
      />
    </div>
  );
}
